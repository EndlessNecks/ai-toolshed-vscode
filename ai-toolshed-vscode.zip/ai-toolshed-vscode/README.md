Adds a two-way automatic project-wide context injection for Codestral using a local RAG system, it will pull context from your project for Codestral to use, and if needed patch your project file directly. This makes Codestral function exactly like VS Code's Copilot (but local).

